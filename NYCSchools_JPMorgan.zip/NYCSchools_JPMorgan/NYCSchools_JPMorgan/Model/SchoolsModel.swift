//
//  SchoolsModel.swift
//  NYCSchools_JPMorgan
//
//  Created by Jha, Richa on 3/29/22.
//

import Foundation
// This is the format in which the schools name and other data can be fetched form the API
//marked all the data fields as optional, to avoid parsing errors.

//commented irrelevant data whcih was not used in desiging ui
struct SchoolsModel: Codable, Identifiable, Equatable {
    var id: String?
    var dbn : String?
    var school_name : String?
//    var boro : String?
    var overview_paragraph : String?
//    var school_10th_seats : String?
//    var academicopportunities1 : String?
//    var academicopportunities2 : String?
//    var ell_programs : String?
//    var neighborhood : String?
//    var building_code : String?
//    var location : String?
    var phone_number : String?
//    var fax_number : String?
    var school_email : String?
    var website : String?
//    var subway : String?
//    var bus : String?
//    var grades2018 : String?
//    var finalgrades : String?
//    var total_students : String?
//    var extracurricular_activities : String?
//    var school_sports : String?
//    var attendance_rate : String?
//    var pct_stu_enough_variety : String?
//    var pct_stu_safe : String?
//    var school_accessibility_description : String?
//    var directions1 : String?
    var requirement1_1 : String?
    var requirement2_1 : String?
//    var requirement3_1 : String?
//    var requirement4_1 : String?
//    var requirement5_1 : String?
//    var offer_rate1 : String?
//    var program1 : String?
//    var code1 : String?
//    var interest1 : String?
//    var method1 : String?
//    var seats9ge1 : String?
//    var grade9gefilledflag1 : String?
//    var grade9geapplicants1 : String?
//    var seats9swd1 : String?
//    var grade9swdfilledflag1 : String?
//    var grade9swdapplicants1 : String?
//    var seats101 : String?
//    var admissionspriority11 : String?
//    var admissionspriority21 : String?
//    var admissionspriority31 : String?
//    var grade9geapplicantsperseat1 : String?
//    var grade9swdapplicantsperseat1 : String?
    var primary_address_line_1 : String?
    var city : String?
    var zip : String?
//    var state_code : String?
    var latitude : String?
    var longitude : String?
//    var community_board : String?
//    var council_district : String?
//    var census_tract : String?
//    var bin : String?
//    var bbl : String?
//    var nta : String?
//    var borough : String?
}

struct MockSchoolsModel {
    
    var mockData : [SchoolsModel] {
        
    [SchoolsModel(id: UUID().uuidString,
                  dbn: "02M260",
                  school_name: "Clinton School Writers & Artists, M.S. 260",
                  overview_paragraph: "Students who are prepared for college must have an education that encourages them to take risks as they produce and perform. Our college preparatory curriculum develops writers and has built a tight-knit community. Our school develops students who can think analytically and write creatively. Our arts programming builds on our 25 years of experience in visual, performing arts and music on a middle school level. We partner with New Audience and the Whitney Museum as cultural partners. We are a International Baccalaureate (IB) candidate school that offers opportunities to take college courses at neighboring universities.",
                  phone_number: "212-524-4360",
                  school_email: "admissions@theclintonschool.net",
                  website: "www.theclintonschool.net",
                  primary_address_line_1: "10 East 15th Street",
                  city: "Manhattan",
                  zip: "48188",
                  latitude:"40.73653",
                  longitude: "-73.9927" ),
     
     SchoolsModel(id: UUID().uuidString,
                  dbn: "21K728",
                  school_name: "Liberation Diploma Plus High School",
                  overview_paragraph: "The mission of Liberation Diploma Plus High School, in partnership with CAMBA, is to develop the student academically, socially, and emotionally. We will equip students with the skills needed to evaluate their options so that they can make informed and appropriate choices and create personal goals for success. Our year-round model (trimesters plus summer school) provides students the opportunity to gain credits and attain required graduation competencies at an accelerated rate. Our partners offer all students career preparation and college exposure. Students have the opportunity to earn college credit(s). In addition to fulfilling New York City graduation requirements, students are required to complete a portfolio to receive a high school diploma.",
                  phone_number: "212-524-4360",
                  school_email: "admissions@theclintonschool.net",
                  website: "schools.nyc.gov/schoolportals/21/K728",
                  primary_address_line_1: "865 West 19th Street",
                  city: "Brooklyn",
                  zip: "11124",
                  latitude:"40.57698",
                  longitude: "-73.9854")]
    }
}

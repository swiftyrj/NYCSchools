//
//  SATScoreModel.swift
//  NYCSchools_JPMorgan
//
//  Created by Jha, Richa on 3/30/22.
//

import Foundation

struct SATScoreModel : Codable {
    var  dbn : String?
    var  school_name : String?
    var  num_of_sat_test_takers : String?
    var  sat_critical_reading_avg_score : String?
    var  sat_math_avg_score : String?
    var  sat_writing_avg_score : String?
}

struct MockSatScoreModel {
    var mockSatScore : [SATScoreModel] {
        [SATScoreModel(dbn: "02M260",
                       school_name: "Clinton School Writers & Artists, M.S. 260",
                       num_of_sat_test_takers: "",
                       sat_critical_reading_avg_score: "",
                       sat_math_avg_score: "",
                       sat_writing_avg_score: ""),
         
        SATScoreModel(dbn: "21K728",
                      school_name: "LIBERATION DIPLOMA PLUS",
                      num_of_sat_test_takers: "10",
                      sat_critical_reading_avg_score: "411",
                      sat_math_avg_score: "369",
                      sat_writing_avg_score: "373")]
    }
}

//
//  NYCSchools_JPMorganApp.swift
//  NYCSchools_JPMorgan
//
//  Created by Jha, Richa on 3/29/22.
//

import SwiftUI

@main
struct NYCSchools_JPMorganApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

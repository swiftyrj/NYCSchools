//
//  NYCSchoolsService.swift
//  NYCSchools_JPMorgan
//
//  Created by Jha, Richa on 3/30/22.
//

import Foundation

//created protocol for dependency injection to be used from test class too
protocol NYCSChoolsServiceable {
    func getListOfNYCSchools(url: URL?, completionHandler: @escaping (Result<[SchoolsModel], NYCSchoolsLocalisedError>) -> Void)
    func getSATScoresForAllNYCSchools(url: URL?, completionHandler: @escaping (Result<[SATScoreModel], NYCSchoolsLocalisedError>) -> Void)
}

struct NYCSchoolsService : NYCSChoolsServiceable {
    
    func getSATScoresForAllNYCSchools(url: URL?, completionHandler: @escaping (Result<[SATScoreModel], NYCSchoolsLocalisedError>) -> Void) {
        
        guard let url = url
        else{ completionHandler(Result.failure(NYCSchoolsLocalisedError.badURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, urlResponse, error in
            if let urlResponse = urlResponse as? HTTPURLResponse, !(200...299).contains(urlResponse.statusCode) {
                completionHandler(Result.failure(NYCSchoolsLocalisedError.badURLResponse(statusCode: urlResponse.statusCode)))
            }
            if let downloadedData = data {
                do {
                    let parsedDataModel = try JSONDecoder().decode([SATScoreModel].self, from: downloadedData)
                    completionHandler(Result.success(parsedDataModel))
                    
                    
                } catch { completionHandler(Result.failure(NYCSchoolsLocalisedError.parsingError(parsingError: error as! DecodingError)))}
            }
        }.resume()
    }
    
    func getListOfNYCSchools(url: URL?, completionHandler: @escaping (Result<[SchoolsModel], NYCSchoolsLocalisedError>) -> Void) {
        
        guard let url = url
        else{ completionHandler(Result.failure(NYCSchoolsLocalisedError.badURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, urlResponse, error in
            if let urlResponse = urlResponse as? HTTPURLResponse, !(200...299).contains(urlResponse.statusCode) {
                completionHandler(Result.failure(NYCSchoolsLocalisedError.badURLResponse(statusCode: urlResponse.statusCode)))
            }
            if let downloadedData = data {
                do {
                    let parsedDataModel = try JSONDecoder().decode([SchoolsModel].self, from: downloadedData)
                    completionHandler(Result.success(parsedDataModel))
                    
                    
                } catch { completionHandler(Result.failure(NYCSchoolsLocalisedError.parsingError(parsingError: error as! DecodingError)))}
            }
        }.resume()
    }
}

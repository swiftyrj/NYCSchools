//
//  NYCSchoolsLocalisedError.swift
//  NYCSchools_JPMorgan
//
//  Created by Jha, Richa on 3/30/22.
//

import Foundation

enum NYCSchoolsLocalisedError: Error, CustomStringConvertible {
    case badURL
    case badURLResponse(statusCode: Int)
    case urlError(urlError: URLError)
    case parsingError(parsingError: DecodingError)
    case unknown
    
    var description: String {
        switch self {
        case .badURL:
            return "URL cannot be connected"
        case .badURLResponse(let statusCode):
            return "bad url response with code \(statusCode)"
        case .urlError(let urlError):
            return "bad url response \(urlError.localizedDescription)"
        case .parsingError(let parsingError):
            return "cannot parse downloaded data \(parsingError)"
        case .unknown:
            return "unknown"
        }
    }
}

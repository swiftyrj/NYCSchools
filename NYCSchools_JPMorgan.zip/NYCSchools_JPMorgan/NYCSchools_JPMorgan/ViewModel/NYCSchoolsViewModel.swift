//
//  NYCSchoolsViewModel.swift
//  NYCSchools_JPMorgan
//
//  Created by Jha, Richa on 3/29/22.
//

import Foundation

class NYCSchoolsViewModel : ObservableObject {
    
    @Published var nycSchoolsData = [SchoolsModel]()
    @Published var nycSatScores = [SATScoreModel]()
    @Published var errorMessage : String? = nil
    @Published var isloading: Bool = false
    var service: NYCSChoolsServiceable
    
    init(service: NYCSChoolsServiceable = NYCSchoolsService()) {
        self.service = service
        fetchListOfNYCSchools()
    }
    
    func fetchListOfNYCSchools() {
        self.isloading = true
        let url = URL(string: "https://data.cityofnewyork.us/resource/s3k6-pzi2.json")
        self.service.getListOfNYCSchools(url: url) { [weak self] result in
            switch result {
            case .failure(let error): self?.errorMessage = error.localizedDescription
            case .success(let schoolsData) :
                DispatchQueue.main.async {
                    self?.isloading = false
                    self?.nycSchoolsData = schoolsData
                    self?.fetchAllSatScores()
                }
            }
        }
    }
    
    func fetchAllSatScores() {
        let url = URL(string: "https://data.cityofnewyork.us/resource/f9bf-2cp4.json")
        self.service.getSATScoresForAllNYCSchools(url: url) { [weak self] result in
           
            switch result {
            case .failure(let error): self?.errorMessage = error.localizedDescription
            case .success(let nycSatScores) :
                DispatchQueue.main.async {
                    self?.isloading = false
                    self?.nycSatScores = nycSatScores
                }
            }
        }
    }
}

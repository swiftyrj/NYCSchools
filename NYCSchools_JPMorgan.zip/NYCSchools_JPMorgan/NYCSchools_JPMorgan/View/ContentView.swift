//
//  ContentView.swift
//  NYCSchools_JPMorgan
//
//  Created by Jha, Richa on 3/29/22.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var viewModel = NYCSchoolsViewModel()
    
    var body: some View {
        if viewModel.isloading {
            LoadingSchoolsView()
        }
        else if viewModel.errorMessage != nil {
            NYCSchoolsErrorView(errorMessage: viewModel.errorMessage ?? "")
        }
        else {
            NYCSchoolsListView(schoolsList: viewModel.nycSchoolsData, schoolSatData: viewModel.nycSatScores)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

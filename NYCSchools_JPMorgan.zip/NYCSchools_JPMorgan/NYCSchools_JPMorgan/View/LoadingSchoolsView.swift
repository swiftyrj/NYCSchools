//
//  LoadingSchoolsView.swift
//  NYCSchools_JPMorgan
//
//  Created by Jha, Richa on 3/30/22.
//

import SwiftUI

struct LoadingSchoolsView: View {
    var body: some View {
        VStack{
            HStack {
               Text("Loading NYC Schools")
                Text("🗽 🏫")
            }
            ProgressView()
        }
    }
}

struct LoadingSchoolsView_Previews: PreviewProvider {
    static var previews: some View {
        LoadingSchoolsView()
    }
}

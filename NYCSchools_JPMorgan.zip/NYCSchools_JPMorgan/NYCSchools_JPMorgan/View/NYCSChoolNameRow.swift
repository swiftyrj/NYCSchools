//
//  NYCSChoolNameRow.swift
//  NYCSchools_JPMorgan
//
//  Created by Jha, Richa on 3/30/22.
//

import SwiftUI

struct NYCSChoolNameRow: View {
    var nycSchoolData : SchoolsModel
    var body: some View {
        VStack(alignment: .leading)
        {
            Text(nycSchoolData.school_name ?? "")
                .foregroundColor(Color.indigo)
                .font(.system(size: 18, weight: .bold, design: .default)).italic()
            
    
            Spacer()
            HStack(alignment: .center){
                Text("ADDRESS:").font(.system(size: 12, weight: .heavy, design: .default))
                let addressString = (nycSchoolData.primary_address_line_1 ?? "") + ", " + (nycSchoolData.city ?? "") + ", " + (nycSchoolData.zip ?? "")
                Text(addressString).font(.system(size: 12, weight: .medium, design: .default))
                
            }
            HStack {
                Text("PHONE NUMBER:").font(.system(size: 12, weight: .heavy, design: .default))
                Text(nycSchoolData.phone_number ?? "") .font(.system(size: 12, weight: .medium, design: .default)).shadow(radius: 5)
            }
            HStack {
                Text("EMAIL:").font(.system(size: 12, weight: .heavy, design: .default))
                Text(nycSchoolData.school_email ?? "") .font(.system(size: 12, weight: .medium, design: .default))
                
            }
        }
        .padding()
        .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
        .cornerRadius(8)
        
    }
}

struct NYCSChoolNameRow_Previews: PreviewProvider {
    static var previews: some View {
        NYCSChoolNameRow(nycSchoolData: MockSchoolsModel().mockData[0])
    }
}

//
//  NYCSchoolsErrorView.swift
//  NYCSchools_JPMorgan
//
//  Created by Jha, Richa on 3/30/22.
//

import SwiftUI

struct NYCSchoolsErrorView: View {
    
    var errorMessage : String = ""
    var body: some View {
        VStack {
            HStack{
                Text("Error Loading NYC Schools 🗽")
                Text(errorMessage)
            }
        }
    }
}

struct NYCSchoolsErrorView_Previews: PreviewProvider {
    static var previews: some View {
        NYCSchoolsErrorView()
    }
}

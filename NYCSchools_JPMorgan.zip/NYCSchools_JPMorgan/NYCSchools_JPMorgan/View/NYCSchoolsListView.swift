//
//  NYCSchoolsListView.swift
//  NYCSchools_JPMorgan
//
//  Created by Jha, Richa on 3/30/22.
//

import SwiftUI

struct NYCSchoolsListView: View {
    var schoolsList = [SchoolsModel]()
    var schoolSatData = [SATScoreModel]()
    @State var filterText : String = ""
    
    var filteredSchoolList : [SchoolsModel] {
        if filterText.count == 0 { return schoolsList }
        else { return schoolsList.filter { ($0.school_name ?? "").contains(filterText)} }
    }
    
    var body: some View {
        NavigationView{
            List {
                ForEach(filteredSchoolList, id: \.dbn) {
                    schoolData in
                    NavigationLink {
                        
                        let satdata = schoolSatData.first(where: {$0.dbn == schoolData.dbn})
                        
                        NYCSchoolsDetailView(nycSatScore: satdata ?? SATScoreModel(), nycSchoolData: schoolData)
                    } label: {
                        NYCSChoolNameRow(nycSchoolData: schoolData)
                    }
                }
            }.listStyle(.grouped)
            .navigationTitle("Find Your School")
        }.searchable(text: $filterText)
    }
}

struct NYCSchoolsListView_Previews: PreviewProvider {
    static var previews: some View {
        NYCSchoolsListView(schoolsList: MockSchoolsModel().mockData)
    }
}

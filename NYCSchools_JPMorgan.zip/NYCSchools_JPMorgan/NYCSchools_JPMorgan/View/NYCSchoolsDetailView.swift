//
//  NYCSchoolsDetailView.swift
//  NYCSchools_JPMorgan
//
//  Created by Jha, Richa on 3/30/22.
//

import SwiftUI
import MapKit

struct City: Identifiable {
    let id = UUID()
    let name: String
    let coordinate: CLLocationCoordinate2D
}

struct NYCSchoolsDetailView: View {
    var nycSatScore: SATScoreModel
    var nycSchoolData: SchoolsModel
    var body: some View {
        VStack (alignment:.leading, spacing: 8) {
            
            let annotations = [
                City(name: nycSchoolData.city ?? "" , coordinate: CLLocationCoordinate2D(latitude: Double(nycSchoolData.latitude ?? "")! , longitude: Double(nycSchoolData.longitude ?? "")!))]
            
            Map(coordinateRegion: .constant(MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: Double(nycSchoolData.latitude ?? "")! , longitude: Double(nycSchoolData.longitude ?? "")!), span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5))), annotationItems: annotations) { MapMarker(coordinate:$0.coordinate)}
         
            Text(nycSchoolData.school_name ?? "").font(.system(size: 18, weight: .heavy, design: .default)).italic()
            
            HStack{
                Text("SAT average Reading score:").font(.system(size: 12, weight: .medium, design: .default))
                Text(nycSatScore.sat_critical_reading_avg_score ?? "UNAVAILABLE").font(.system(size: 12, weight: .medium, design: .default))
            }
            HStack{
                Text("SAT average Math score:").font(.system(size: 12, weight: .medium, design: .default))
                Text(nycSatScore.sat_math_avg_score ?? "UNAVAILABLE").font(.system(size: 12, weight: .medium, design: .default))
            }
            HStack{
                Text("SAT average Writing score:").font(.system(size: 12, weight: .medium, design: .default))
                Text(nycSatScore.sat_writing_avg_score ?? "UNAVAILABLE").font(.system(size: 12, weight: .medium, design: .default))
            }
            
            Divider()
            
            Text("OVERVIEW").font(.system(size: 15, weight: .heavy, design: .default)).italic()
            
            Text(nycSchoolData.overview_paragraph ?? "").font(.system(size: 14, weight: .medium, design: .default))
            
            Divider()
            
            HStack {
                Text("PHONE NUMBER:").font(.system(size: 12, weight: .heavy, design: .default))
                Link(destination: URL(string: nycSchoolData.phone_number ?? "")!) {
                    Text(nycSchoolData.phone_number ?? "") .font(.system(size: 12, weight: .medium, design: .default)).shadow(radius: 5)
                }
            }
        }.padding()
        Spacer()
    }
}

struct NYCSchoolsDetailView_Previews: PreviewProvider {
    static var previews: some View {
        NYCSchoolsDetailView(nycSatScore: SATScoreModel(), nycSchoolData: SchoolsModel())
    }
}

//
//  NYCSchoolsServiceTests.swift
//  NYCSchools_JPMorganUnitTests
//
//  Created by Jha, Richa on 3/31/22.
//

import Foundation
import XCTest
import Combine

@testable import NYCSchools_JPMorgan
import SwiftUI

class NYCSchoolsServiceTests: XCTestCase {
    
    var subject : NYCSchoolsViewModel!
    var mockService: NYCSChoolsServiceable!
    var myCancellable = Set<AnyCancellable>()
    
    // Put setup code here. This method is called before the invocation of each test method in the class.
    override func setUpWithError() throws {
        mockService = MockNYCSchoolsService(schoolDataResult: Result.success(MockSchoolsModel().mockData),
                                            satScoreResult: Result.success(MockSatScoreModel().mockSatScore))
        
        subject = NYCSchoolsViewModel(service: mockService)
    }

    // Put teardown code here. This method is called after the invocation of each test method in the class.
    override func tearDownWithError() throws {
       mockService = nil
       subject = nil
    }

    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
    // Any test you write for XCTest can be annotated as throws and async.
    // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
    // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    
    func testGetListOfNYCSchoolsSuccess() {
        let expectation = XCTestExpectation(description: "List of NYC schools Success")
        subject.$nycSchoolsData.dropFirst().sink { schoolsModel in
            expectation.fulfill()
          
        }.store(in: &myCancellable)
        wait(for: [expectation], timeout: 5)
        XCTAssertFalse(subject.nycSchoolsData.isEmpty)
    }
    
    func testGetSATScoresForNYCSchoolsSuccess() {
        let expectation = XCTestExpectation(description: "List of SAT scores For NYC SChools")
        subject.$nycSatScores.dropFirst().sink { satScores in
            expectation.fulfill()
        }.store(in: &myCancellable)
        
        wait(for: [expectation], timeout: 5)
        XCTAssertFalse(subject.nycSatScores.isEmpty)
    }
    
    //API failure test case: this can be used for all other error currently handled only bad url part
    func testGetListOfNYCSchoolsFailureDueToBadURL() {
        let expectation = XCTestExpectation(description: "List of NYC schools Failure")
        
        
        mockService = MockNYCSchoolsService(schoolDataResult: Result.failure(NYCSchoolsLocalisedError.badURL), satScoreResult: Result.failure(NYCSchoolsLocalisedError.badURL))
        
        subject = NYCSchoolsViewModel(service: mockService)
        subject.$errorMessage.dropFirst().sink { error in
            expectation.fulfill()
        }.store(in: &myCancellable)
        
        subject.fetchListOfNYCSchools()
        wait(for: [expectation], timeout: 5)
        XCTAssertNotNil(subject.errorMessage?.description)
        
    }
}

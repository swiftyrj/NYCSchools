//
//  MockNYCSchoolsService.swift
//  NYCSchools_JPMorganUnitTests
//
//  Created by Jha, Richa on 3/31/22.
//

import Foundation
@testable import NYCSchools_JPMorgan

class MockNYCSchoolsService : NYCSChoolsServiceable {
    var schoolDataResult: Result<[SchoolsModel], NYCSchoolsLocalisedError>
    var satScoreResult: Result<[SATScoreModel], NYCSchoolsLocalisedError>
    
    init(schoolDataResult: Result<[SchoolsModel], NYCSchoolsLocalisedError>,
         satScoreResult: Result<[SATScoreModel], NYCSchoolsLocalisedError>) {
        self.schoolDataResult = schoolDataResult
        self.satScoreResult = satScoreResult
    }
    
    func getListOfNYCSchools(url: URL?, completionHandler: @escaping (Result<[SchoolsModel], NYCSchoolsLocalisedError>) -> Void) {
        completionHandler(schoolDataResult)
    }
    
    func getSATScoresForAllNYCSchools(url: URL?, completionHandler: @escaping (Result<[SATScoreModel], NYCSchoolsLocalisedError>) -> Void) {
        completionHandler(satScoreResult)
    }
}
